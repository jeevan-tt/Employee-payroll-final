package com.emp.payroll.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.emp.payroll.model.Employee;

public interface EmpRepository extends JpaRepository<Employee, Integer>{

	public List<Employee> findByEmailId(String mobNo);

	public Employee save(List<Employee> employee);

}
